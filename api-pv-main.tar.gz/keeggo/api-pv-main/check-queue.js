const { ServiceBusClient } = require('@azure/service-bus');

const connectionString = 'Endpoint=sb://demo-poli.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=4LM2c7So9HQD/gJ2iB6/diWftnPXBS7jx+ASbGbPx4I=';
const queueName = 'pedidos';

async function checkQueue() {
    const client = new ServiceBusClient(connectionString);
    const receiver = client.createReceiver(queueName);
    
    // Tentar receber mensagens com timeout maior
    console.log('🔍 Aguardando mensagens por 10 segundos...');
    const messages = await receiver.receiveMessages(5, { maxWaitTimeInMs: 10000 });
    
    console.log(`📨 Total de mensagens encontradas: ${messages.length}`);
    messages.forEach((msg, i) => {
        console.log(`Mensagem ${i + 1}:`, msg.body);
        console.log(`   Tipo: ${msg.applicationProperties?.tipo}`);
        console.log(`   MessageId: ${msg.messageId}`);
    });
    
    if (messages.length > 0) {
        console.log('✅ Processando mensagens...');
        for (const msg of messages) {
            await receiver.completeMessage(msg);
        }
        console.log('✅ Mensagens processadas e removidas da queue');
    }
    
    await receiver.close();
    await client.close();
}

checkQueue().catch(console.error);
