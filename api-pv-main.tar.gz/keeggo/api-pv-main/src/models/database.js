// src/models/database.js
const { Pool } = require('pg');
const { logger } = require('../lib/logger');

class Database {
    constructor() {
        this.pool = new Pool({
            host: process.env.DB_HOST,
            port: process.env.DB_PORT,
            database: process.env.DB_NAME,
            user: process.env.DB_USER,
            password: process.env.DB_PASSWORD,
            max: 20,
            idleTimeoutMillis: 30000,
            connectionTimeoutMillis: 2000,
        });

        this.pool.on('connect', () => {
            logger.info('Conectado ao PostgreSQL');
        });

        this.pool.on('error', (err) => {
            logger.error('Erro no pool de conexões', { error: err.message });
        });
    }

    async query(text, params) {
        const start = Date.now();
        try {
            const result = await this.pool.query(text, params);
            const duration = Date.now() - start;
            if (duration > 100) {
                logger.warn('Query lenta', { duration, rows: result.rowCount });
            }
            return result;
        } catch (error) {
            logger.error('Erro na query', { error: error.message });
            throw error;
        }
    }

    async testConnection() {
        try {
            const result = await this.query('SELECT NOW()');
            logger.info('Banco de dados conectado', { now: result.rows[0].now });
            return true;
        } catch (error) {
            logger.error('Erro ao conectar ao banco', { error: error.message });
            return false;
        }
    }

    async close() {
        await this.pool.end();
        logger.info('Conexões com banco fechadas');
    }
}

// Exportar uma única instância (singleton)
module.exports = new Database();