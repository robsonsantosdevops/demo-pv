// src/services/metricsService.js
//
// CORREÇÃO: em vez de criar transações APM órfãs com apm.startTransaction(),
// agora usamos apm.currentTransaction — que já existe dentro do contexto da
// request HTTP do Express. Isso correlaciona os eventos de negócio com a
// trace da requisição no Kibana APM (trace ID, span ID, latência, etc.).
//
// Para eventos genuinamente fora de request (jobs, scripts), cria uma
// transação standalone curta — mas isso não deve ocorrer no fluxo normal.

const apm = require('elastic-apm-node');
const { logger } = require('../lib/logger');

class MetricsService {

    /**
     * Adiciona labels ao contexto APM atual (request em andamento).
     * Se não houver contexto, cria uma transação standalone curta.
     */
    static _addLabels(labels) {
        const tx = apm.currentTransaction;
        if (tx) {
            Object.entries(labels).forEach(([k, v]) => apm.setLabel(k, v));
        } else {
            const standalone = apm.startTransaction(
                labels['business_transaction'] || 'business_event',
                'business'
            );
            Object.entries(labels).forEach(([k, v]) => apm.setLabel(k, v));
            if (standalone) standalone.end();
        }
    }

    // ─── Aluno cadastrado ──────────────────────────────────────────────────────
    static recordAlunoCadastrado(aluno) {
        MetricsService._addLabels({
            business_transaction: 'aluno_cadastrado',
            business_aluno_id: String(aluno.id),
            business_aluno_email: aluno.email,
        });

        apm.setCustomContext({
            aluno: { id: aluno.id, email: aluno.email, created_at: aluno.created_at }
        });

        logger.info('📊 [METRICA] Aluno cadastrado', {
            business: {
                transaction: 'aluno_cadastrado',
                aluno: { id: aluno.id, email: aluno.email, created_at: aluno.created_at },
            }
        });
    }

    // ─── Pedido criado ─────────────────────────────────────────────────────────
    static recordPedidoCriado(pedido, alunoId) {
        MetricsService._addLabels({
            business_transaction: 'pedido_criado',
            business_pedido_id: String(pedido.id),
            business_pedido_total: pedido.total,
            business_aluno_id: String(alunoId),
        });

        apm.setCustomContext({
            pedido: { id: pedido.id, numero: pedido.numero_pedido, total: pedido.total, status: pedido.status }
        });

        logger.info('📊 [METRICA] Pedido criado', {
            business: {
                transaction: 'pedido_criado',
                pedido: {
                    id: pedido.id,
                    numero: pedido.numero_pedido,
                    total: pedido.total,
                    status: pedido.status,
                    parcelas: pedido.parcelas,
                },
                aluno: { id: alunoId },
            }
        });
    }

    // ─── Itens do pedido (cursos comprados) ────────────────────────────────────
    static recordItensPedido(pedidoId, itens, alunoId) {
        // Labels do APM refletem o totalizador do pedido inteiro
        MetricsService._addLabels({
            business_transaction: 'curso_comprado',
            business_pedido_id: String(pedidoId),
            business_aluno_id: String(alunoId),
            business_total_cursos: itens.length,
        });

        // Cada item vira um log separado — o Logstash indexa como documento individual
        // permitindo agregações por curso no Kibana (top cursos, receita por curso, etc.)
        itens.forEach(item => {
            logger.info('📊 [METRICA] Curso comprado', {
                business: {
                    transaction: 'curso_comprado',
                    curso: {
                        id: item.curso_id,
                        titulo: item.curso_titulo,
                        quantidade: item.quantidade,
                        preco_unitario: item.preco_unitario,
                    },
                    pedido: { id: pedidoId },
                    aluno: { id: alunoId },
                    valor_total: item.preco_unitario * item.quantidade,
                }
            });
        });
    }

    // ─── Pagamento aprovado ────────────────────────────────────────────────────
    static recordPagamentoAprovado(pagamento, pedidoId, alunoId) {
        MetricsService._addLabels({
            business_transaction: 'pagamento_aprovado',
            business_pagamento_id: String(pagamento.id),
            business_pagamento_forma: pagamento.forma_pagamento,
            business_valor: pagamento.valor,
            business_pedido_id: String(pedidoId),
            business_aluno_id: String(alunoId),
            business_receita: pagamento.valor,
        });

        apm.setCustomContext({
            pagamento: {
                id: pagamento.id,
                protocolo: pagamento.protocolo,
                forma: pagamento.forma_pagamento,
                parcelas: pagamento.parcelas,
            }
        });

        logger.info('📊 [METRICA] Pagamento aprovado', {
            business: {
                transaction: 'pagamento_aprovado',
                pagamento: {
                    id: pagamento.id,
                    protocolo: pagamento.protocolo,
                    forma: pagamento.forma_pagamento,
                    parcelas: pagamento.parcelas,
                },
                pedido: { id: pedidoId },
                aluno: { id: alunoId },
                valor: pagamento.valor,
                metrics: { receita: pagamento.valor, conversao: 1 },
            }
        });
    }

    // ─── Checkout iniciado ─────────────────────────────────────────────────────
    static recordCheckoutInicio(alunoId, valorTotal) {
        MetricsService._addLabels({
            business_transaction: 'checkout_iniciado',
            business_aluno_id: String(alunoId),
            business_valor: valorTotal,
        });

        logger.info('📊 [METRICA] Checkout iniciado', {
            business: {
                transaction: 'checkout_iniciado',
                aluno: { id: alunoId },
                valor: valorTotal,
            }
        });
    }
}

module.exports = MetricsService;