const { ServiceBusClient } = require('@azure/service-bus');
const { logger } = require('../lib/logger');

let client = null;

function getClient() {
    if (!client) {
        const connectionString = process.env.AZURE_SERVICE_BUS_CONNECTION_STRING;

        if (!connectionString) {
            logger.error('[SERVICE_BUS] Integração indisponível: AZURE_SERVICE_BUS_CONNECTION_STRING não definida', {
                falha_integracao: true,
                motivo: 'connection_string_ausente',
            });
            throw new Error('AZURE_SERVICE_BUS_CONNECTION_STRING não definida no .env');
        }

        try {
            client = new ServiceBusClient(connectionString);
            logger.info('[SERVICE_BUS] ServiceBusClient inicializado', {
                service: 'service-bus',
            });
        } catch (err) {
            logger.error('[SERVICE_BUS] Falha ao criar ServiceBusClient', {
                falha_integracao: true,
                motivo: 'instancia_cliente',
                erro: err.message,
                codigo: err.code,
                stack: err.stack,
            });
            throw err;
        }
    }

    return client;
}

async function closeClient() {
    if (client) {
        await client.close();
        client = null;
        logger.info('ServiceBusClient encerrado', { service: 'service-bus' });
    }
}

module.exports = { getClient, closeClient };
