const { getClient } = require('./serviceBusClient');
const { logger } = require('../lib/logger');

const QUEUE_NAME = process.env.AZURE_SERVICE_BUS_QUEUE_NAME || 'pedidos';

let sender = null;

function getSender() {
    if (!sender) {
        sender = getClient().createSender(QUEUE_NAME);
    }
    return sender;
}

/**
 * Envia uma mensagem para a queue do Service Bus.
 * O traceparent é extraído do APM e viaja nas applicationProperties
 * para que o consumer consiga retomar o trace no Kibana.
 *
 * @param {object} payload  - Dados da mensagem (ex: pedido, pagamento)
 * @param {string} tipo     - Tipo da mensagem (ex: 'pedido_criado', 'pagamento_aprovado')
 * @param {object} req      - Request Express — usado para extrair o traceparent
 */
async function enviarMensagem(payload, tipo, req) {
    const apm = require('elastic-apm-node');

    // Captura o span atual do APM para criar um span filho de messaging
    const span = apm.startSpan(`Service Bus send ${QUEUE_NAME}`, 'messaging', 'azureservicebus', 'send');

    // Propaga o traceparent: tenta pegar do header HTTP recebido,
    // ou gera a partir do transaction ativo no APM
    const traceparent =
        req?.headers?.traceparent ||
        (apm.currentTransaction ? apm.currentTransaction.traceparent : null);

    const tracestate =
        req?.headers?.tracestate || null;

    const mensagem = {
        body: {
            tipo,
            payload,
            timestamp: new Date().toISOString(),
        },
        applicationProperties: {
            tipo,
            // W3C Trace Context — o consumer vai ler isso para retomar o trace
            ...(traceparent && { traceparent }),
            ...(tracestate && { tracestate }),
        },
        contentType: 'application/json',
        // messageId único por mensagem para deduplicação no Service Bus
        messageId: `${tipo}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    };

    try {
        await getSender().sendMessages(mensagem);

        logger.info('[SERVICE_BUS] Mensagem enviada para a fila', {
            queue: QUEUE_NAME,
            tipo,
            messageId: mensagem.messageId,
            traceparent: traceparent || 'não disponível',
        });

        span?.setOutcome('success');
        return { sucesso: true, messageId: mensagem.messageId };
    } catch (err) {
        logger.error('[SERVICE_BUS] Falha ao enviar mensagem — integração não concluída', {
            falha_integracao: true,
            queue: QUEUE_NAME,
            tipo,
            messageId: mensagem.messageId,
            erro: err.message,
            codigo: err.code,
            statusCode: err.statusCode,
            nome: err.name,
            stack: err.stack,
        });

        span?.setOutcome('failure');
        apm.captureError(err);
        throw err;
    } finally {
        span?.end();
    }
}

async function closeSender() {
    if (sender) {
        await sender.close();
        sender = null;
    }
}

module.exports = { enviarMensagem, closeSender };
