const axios = require('axios');
const { logger } = require('../lib/logger');

const SAP_URL = process.env.SAP_URL || 'http://mock-sap:4000';

/**
 * Encaminha a mensagem para o SAP (ou Mock SAP).
 * Propaga o traceparent no header HTTP para manter a cadeia de trace
 * visível no Kibana como um único fluxo de ponta a ponta.
 *
 * @param {object} mensagem     - Mensagem recebida da queue
 * @param {string} traceparent  - Header W3C Trace Context para propagação
 * @param {string} tracestate   - Header W3C tracestate (opcional)
 */
async function encaminharParaSap(mensagem, traceparent, tracestate) {
    const apm = require('elastic-apm-node');
    const span = apm.startSpan('SAP HTTP send', 'external', 'http', 'request');

    const headers = {
        'Content-Type': 'application/json',
        // Propaga o trace para o SAP — se o SAP tiver APM, o trace continua lá
        ...(traceparent && { traceparent }),
        ...(tracestate && { tracestate }),
    };

    const endpoint = resolverEndpoint(mensagem.tipo);

    try {
        const resposta = await axios.post(`${SAP_URL}${endpoint}`, mensagem, { headers });

        logger.info('Mensagem encaminhada ao SAP com sucesso', {
            tipo: mensagem.tipo,
            endpoint,
            status: resposta.status,
            traceparent: traceparent || 'não disponível',
        });

        span?.setOutcome('success');
        return { sucesso: true, status: resposta.status };
    } catch (err) {
        const status = err.response?.status;

        logger.error('Erro ao encaminhar mensagem ao SAP', {
            tipo: mensagem.tipo,
            endpoint,
            status,
            error: err.message,
        });

        span?.setOutcome('failure');
        apm.captureError(err);
        throw err;
    } finally {
        span?.end();
    }
}

/**
 * Mapeia o tipo da mensagem para o endpoint correto no SAP
 */
function resolverEndpoint(tipo) {
    const mapa = {
        pedido_criado: '/api/sap/pedidos',
        pagamento_aprovado: '/api/sap/pagamentos',
    };

    return mapa[tipo] || '/api/sap/eventos';
}

module.exports = { encaminharParaSap };