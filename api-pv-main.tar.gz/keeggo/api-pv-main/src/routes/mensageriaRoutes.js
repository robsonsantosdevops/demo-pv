const express = require('express');
const router = express.Router();
const { enviarMensagem } = require('../messaging/producer');
const { logger } = require('../lib/logger');

/**
 * POST /api/mensageria/pedido
 * Recebe um evento de pedido e coloca na queue
 */
router.post('/pedido', async (req, res) => {
    const { body } = req;

    if (!body || Object.keys(body).length === 0) {
        return res.status(400).json({ erro: 'Body da requisição não pode ser vazio' });
    }

    try {
        const resultado = await enviarMensagem(body, 'pedido_criado', req);

        logger.info('Pedido enfileirado com sucesso', {
            messageId: resultado.messageId,
            traceparent: req.headers.traceparent,
        });

        return res.status(202).json({
            mensagem: 'Pedido recebido e enfileirado',
            messageId: resultado.messageId,
            status: 'enqueued',
        });
    } catch (err) {
        logger.error('[SERVICE_BUS] Falha ao enfileirar pedido (rota mensageria)', {
            falha_integracao: true,
            erro: err.message,
            codigo: err.code,
            stack: err.stack,
        });
        return res.status(500).json({ erro: 'Falha ao enfileirar mensagem' });
    }
});

/**
 * POST /api/mensageria/pagamento
 * Recebe um evento de pagamento e coloca na queue
 */
router.post('/pagamento', async (req, res) => {
    const { body } = req;

    if (!body || Object.keys(body).length === 0) {
        return res.status(400).json({ erro: 'Body da requisição não pode ser vazio' });
    }

    try {
        const resultado = await enviarMensagem(body, 'pagamento_aprovado', req);

        logger.info('Pagamento enfileirado com sucesso', {
            messageId: resultado.messageId,
            traceparent: req.headers.traceparent,
        });

        return res.status(202).json({
            mensagem: 'Pagamento recebido e enfileirado',
            messageId: resultado.messageId,
            status: 'enqueued',
        });
    } catch (err) {
        logger.error('[SERVICE_BUS] Falha ao enfileirar pagamento (rota mensageria)', {
            falha_integracao: true,
            erro: err.message,
            codigo: err.code,
            stack: err.stack,
        });
        return res.status(500).json({ erro: 'Falha ao enfileirar mensagem' });
    }
});

/**
 * GET /api/mensageria/health
 * Health check específico do serviço de mensageria
 */
router.get('/health', (req, res) => {
    res.json({
        status: 'OK',
        servico: 'mensageria',
        queue: process.env.AZURE_SERVICE_BUS_QUEUE_NAME || 'pedidos',
        timestamp: new Date().toISOString(),
    });
});

module.exports = router;
