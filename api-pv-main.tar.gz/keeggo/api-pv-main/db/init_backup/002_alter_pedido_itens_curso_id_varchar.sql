-- Migration: 002_alter_pedido_itens_curso_id_varchar.sql
-- Description: Altera curso_id de INTEGER para VARCHAR(100)
-- Motivo: cursos usam slugs semanticos como identificador (ex: "medicina-online")
-- Executar com:
--   docker exec -i poliedro-postgres psql -U postgres -d poliedro_db -1 -f - < 002_alter_pedido_itens_curso_id_varchar.sql

-- 1. Remove o indice antigo (era INTEGER, precisa recriar em VARCHAR)
DROP INDEX IF EXISTS idx_pedido_itens_curso_id;

-- 2. Adiciona coluna temporaria com o tipo correto
ALTER TABLE pedido_itens ADD COLUMN curso_id_new VARCHAR(100);

-- 3. Copia dados existentes convertendo integer para text
UPDATE pedido_itens SET curso_id_new = curso_id::TEXT WHERE curso_id IS NOT NULL;

-- 4. Remove coluna antiga
ALTER TABLE pedido_itens DROP COLUMN curso_id;

-- 5. Renomeia nova coluna para o nome original
ALTER TABLE pedido_itens RENAME COLUMN curso_id_new TO curso_id;

-- 6. Recria o indice com o tipo correto
CREATE INDEX idx_pedido_itens_curso_id ON pedido_itens(curso_id);