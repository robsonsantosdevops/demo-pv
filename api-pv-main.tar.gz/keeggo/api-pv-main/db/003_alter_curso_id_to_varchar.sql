ALTER TABLE pedido_itens ALTER COLUMN curso_id TYPE VARCHAR(100);
DROP INDEX IF EXISTS idx_pedido_itens_curso_id;
CREATE INDEX IF NOT EXISTS idx_pedido_itens_curso_id ON pedido_itens(curso_id);
