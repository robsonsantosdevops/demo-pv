-- Migration: Add correlation_id to pedidos
-- Description: Adiciona correlation_id para rastreamento de jornada do aluno
-- Permite identificar se um aluno iniciou o pedido mas não finalizou o pagamento

ALTER TABLE pedidos 
ADD COLUMN IF NOT EXISTS correlation_id VARCHAR(100);

CREATE INDEX IF NOT EXISTS idx_pedidos_correlation_id ON pedidos(correlation_id);