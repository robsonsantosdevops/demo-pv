// scripts/seed_data.js
// Popula o banco com dados realistas dos ultimos 30 dias
// Simula padroes reais: pico no inicio do mes, queda no meio, recuperacao no fim
//
// Executar de dentro da pasta api-pv-main:
//   node scripts/seed_data.js

require('dotenv').config();
const { Pool } = require('pg');
const axios = require('axios');

const pool = new Pool({
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 5432,
    database: process.env.DB_NAME || 'poliedro_db',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'postgres',
});

const LOGSTASH_URL = `http://${process.env.LOGSTASH_HOST || 'localhost'}:${process.env.LOGSTASH_PORT || 5000}`;

// Cursos exatamente como definidos no frontend (CoursesSection)
// maxParcelas = maximo permitido por curso conforme regra de negocio
const CURSOS = [
    { id: 'medicina-online', titulo: 'Medicina Online', preco: 14990, maxParcelas: 12 },
    { id: 'ita-online', titulo: 'Turma ITA Online', preco: 16990, maxParcelas: 12 },
    { id: 'enem-online', titulo: 'Enem Online', preco: 12990, maxParcelas: 10 },
    { id: 'extensivo-manha', titulo: 'Extensivo Manha', preco: 13990, maxParcelas: 10 },
];

const FORMAS_PAGAMENTO = [
    { forma: 'pix', peso: 45 },
    { forma: 'cartao', peso: 40 },
    { forma: 'boleto', peso: 15 },
];

// Nomes para os alunos seed
const NOMES = [
    'Ana Carolina Silva', 'Bruno Henrique Santos', 'Camila Oliveira Lima',
    'Diego Fernandes Costa', 'Eduarda Martins Souza', 'Felipe Rodrigues Alves',
    'Gabriela Pereira Dias', 'Henrique Moura Castro', 'Isabella Carvalho Rocha',
    'Joao Victor Mendes', 'Karla Nascimento Pinto', 'Lucas Teixeira Freitas',
    'Mariana Barbosa Nunes', 'Nicolas Azevedo Gomes', 'Olivia Monteiro Lopes',
    'Pedro Henrique Cunha', 'Rafaela Ribeiro Vieira', 'Samuel Fonseca Cardoso',
    'Tatiana Batista Araujo', 'Victor Hugo Andrade',
];

function randomItem(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}

function weightedForma() {
    const total = FORMAS_PAGAMENTO.reduce((s, f) => s + f.peso, 0);
    let r = Math.random() * total;
    for (const f of FORMAS_PAGAMENTO) {
        r -= f.peso;
        if (r <= 0) return f.forma;
    }
    return 'pix';
}

// Parcelas respeitam forma + maxParcelas do curso (regra do formulario)
// PIX e boleto: sempre 1x
// Cartao: opcoes variaveis ate o maxParcelas
function calcParcelas(forma, maxParcelas) {
    if (forma === 'pix' || forma === 'boleto') return 1;
    const opcoes = [1, 2, 3, 6, 10, 12].filter(p => p <= maxParcelas);
    return randomItem(opcoes);
}

// Volume diario com padrao realista (pico inicio e fim do mes)
function volumePorDia(diaDoMes) {
    if (diaDoMes <= 5) return Math.floor(Math.random() * 4) + 3;  // inicio: 3-6
    if (diaDoMes <= 10) return Math.floor(Math.random() * 3) + 2;  // queda: 2-4
    if (diaDoMes <= 20) return Math.floor(Math.random() * 2) + 1;  // meio: 1-2
    if (diaDoMes <= 25) return Math.floor(Math.random() * 3) + 2;  // recuperacao: 2-4
    return Math.floor(Math.random() * 4) + 3;                       // fim: 3-6
}

// CPF valido de 11 digitos numericos (validacao do controller)
function gerarCPF(index) {
    const base = String(10000000 + index).padStart(9, '0');
    return base + '00';
}

// Email valido (validacao do controller: /^[^\s@]+@[^\s@]+\.[^\s@]+$/)
function gerarEmail(index, timestamp) {
    return `aluno.seed${index}.${timestamp}@poliedro.demo`;
}

// Telefone valido: 10 ou 11 digitos numericos (validacao do controller)
function gerarTelefone(index) {
    return `119${String(10000000 + index).slice(0, 8)}`;
}

function gerarProtocolo(timestamp) {
    return `PAG-${timestamp}-${Math.floor(Math.random() * 999)}`;
}

function gerarNumeroPedido(timestamp) {
    const t = timestamp.toString(36).toUpperCase();
    const r = Math.floor(Math.random() * 10000).toString(36).toUpperCase();
    return `PED-${t}-${r}`;
}

async function sendToLogstash(logData) {
    try {
        await axios.post(LOGSTASH_URL, logData, {
            headers: { 'Content-Type': 'application/json' },
            timeout: 3000,
        });
    } catch {
        // Logstash nao e critico para o seed
    }
}

async function inserirAluno(client, nome, index, data) {
    const ts = data.getTime();
    const cpf = gerarCPF(index);
    const email = gerarEmail(index, ts);
    const telefone = gerarTelefone(index);

    // nome: minimo 3 chars (validacao do controller)
    // cpf: 11 digitos numericos
    // email: formato valido
    // telefone: 10-11 digitos
    const result = await client.query(
        `INSERT INTO alunos (nome_completo, cpf, email, telefone, created_at, updated_at)
     VALUES ($1, $2, $3, $4, $5, $5)
     RETURNING id`,
        [nome, cpf, email, telefone, data]
    );

    const alunoId = result.rows[0].id;

    await sendToLogstash({
        '@timestamp': data.toISOString(),
        level: 'info',
        message: '[METRICA] Aluno cadastrado',
        service: 'api-pv',
        business: {
            transaction: 'aluno_cadastrado',
            aluno: { id: alunoId, email, created_at: data },
        }
    });

    return { id: alunoId, email };
}

async function inserirPedidoEPagamento(client, aluno, data) {
    const curso = randomItem(CURSOS);
    const forma = weightedForma();
    const parcelas = calcParcelas(forma, curso.maxParcelas);
    const total = curso.preco;
    const ts = data.getTime();
    const numPedido = gerarNumeroPedido(ts);

    // Pedido
    const pedidoResult = await client.query(
        `INSERT INTO pedidos (aluno_id, numero_pedido, status, total, parcelas, created_at, updated_at)
     VALUES ($1, $2, 'aguardando_pagamento', $3, $4, $5, $5)
     RETURNING id`,
        [aluno.id, numPedido, total, parcelas, data]
    );
    const pedidoId = pedidoResult.rows[0].id;

    // Item — curso_id e VARCHAR conforme migration 002
    await client.query(
        `INSERT INTO pedido_itens (pedido_id, curso_id, curso_titulo, quantidade, preco_unitario, created_at, updated_at)
     VALUES ($1, $2, $3, 1, $4, $5, $5)`,
        [pedidoId, curso.id, curso.titulo, curso.preco, data]
    );

    // Pagamento
    const protocolo = gerarProtocolo(ts);
    const pagResult = await client.query(
        `INSERT INTO pagamentos (aluno_id, forma_pagamento, valor, parcelas, protocolo, status, created_at, updated_at)
     VALUES ($1, $2, $3, $4, $5, 'aprovado', $6, $6)
     RETURNING id`,
        [aluno.id, forma, total, parcelas, protocolo, data]
    );
    const pagId = pagResult.rows[0].id;

    // Atualiza pedido para pago
    await client.query(
        `UPDATE pedidos SET status = 'pago', pagamento_id = $1, updated_at = $3 WHERE id = $2`,
        [pagId, pedidoId, data]
    );

    const baseLog = { '@timestamp': data.toISOString(), service: 'api-pv', level: 'info' };

    await sendToLogstash({
        ...baseLog, message: '[METRICA] Checkout iniciado',
        business: { transaction: 'checkout_iniciado', aluno: { id: aluno.id }, valor: total }
    });

    await sendToLogstash({
        ...baseLog, message: '[METRICA] Pedido criado',
        business: {
            transaction: 'pedido_criado',
            pedido: { id: pedidoId, numero: numPedido, total, status: 'aguardando_pagamento' },
            aluno: { id: aluno.id },
        }
    });

    await sendToLogstash({
        ...baseLog, message: '[METRICA] Curso comprado',
        business: {
            transaction: 'curso_comprado',
            curso: { id: curso.id, titulo: curso.titulo, quantidade: 1, preco_unitario: curso.preco },
            pedido: { id: pedidoId },
            aluno: { id: aluno.id },
            valor_total: total,
        }
    });

    await sendToLogstash({
        ...baseLog, message: '[METRICA] Pagamento aprovado',
        business: {
            transaction: 'pagamento_aprovado',
            pagamento: { id: pagId, protocolo, forma, parcelas },
            pedido: { id: pedidoId },
            aluno: { id: aluno.id },
            valor: total,
            metrics: { receita: total, conversao: 1 },
        }
    });

    return { curso, forma, parcelas, total };
}

async function main() {
    const client = await pool.connect();

    try {
        console.log('Iniciando seed de dados - ultimos 30 dias\n');

        const hoje = new Date();
        let totalAlunos = 0;
        let totalReceita = 0;
        let alunoIndex = 1000;

        for (let diasAtras = 29; diasAtras >= 0; diasAtras--) {
            const data = new Date(hoje);
            data.setDate(hoje.getDate() - diasAtras);
            data.setHours(0, 0, 0, 0);

            const diaDoMes = data.getDate();
            const volume = volumePorDia(diaDoMes);

            console.log(`${data.toISOString().slice(0, 10)} - ${volume} matriculas`);

            for (let i = 0; i < volume; i++) {
                const hora = new Date(data);
                hora.setHours(
                    8 + Math.floor(Math.random() * 12),
                    Math.floor(Math.random() * 60),
                    Math.floor(Math.random() * 60)
                );

                const nome = randomItem(NOMES);
                const aluno = await inserirAluno(client, nome, alunoIndex++, hora);
                const { curso, forma, parcelas, total } = await inserirPedidoEPagamento(client, aluno, hora);

                console.log(`  + ${nome} - ${curso.titulo} (${forma} ${parcelas}x) R$ ${total.toLocaleString('pt-BR')}`);

                totalAlunos++;
                totalReceita += total;

                await new Promise(r => setTimeout(r, 50));
            }
        }

        console.log('\nSeed concluido!');
        console.log(`  Alunos inseridos: ${totalAlunos}`);
        console.log(`  Receita total:    R$ ${totalReceita.toLocaleString('pt-BR')}`);
        console.log('\nAguarde ~30 segundos para os dados aparecerem no Kibana.');

    } catch (err) {
        console.error('Erro durante o seed:', err.message);
        throw err;
    } finally {
        client.release();
        await pool.end();
    }
}

main();