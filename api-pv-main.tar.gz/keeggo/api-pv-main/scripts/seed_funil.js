// scripts/seed_funil.js
// Seed especifico para popular o funil de conversao com abandono realista
// Simula comportamento real: nem todo checkout vira pedido, nem todo pedido vira pagamento
//
// Executar: node scripts/seed_funil.js

require('dotenv').config();
const axios = require('axios');
const { Pool } = require('pg');

const pool = new Pool({
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 5432,
    database: process.env.DB_NAME || 'poliedro_db',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || 'postgres',
});

const LOGSTASH_URL = `http://${process.env.LOGSTASH_HOST || 'localhost'}:${process.env.LOGSTASH_PORT || 5000}`;

const CURSOS = [
    { id: 'medicina-online', titulo: 'Medicina Online', preco: 14990, maxParcelas: 12 },
    { id: 'ita-online', titulo: 'Turma ITA Online', preco: 16990, maxParcelas: 12 },
    { id: 'enem-online', titulo: 'Enem Online', preco: 12990, maxParcelas: 10 },
    { id: 'extensivo-manha', titulo: 'Extensivo Manha', preco: 13990, maxParcelas: 10 },
];

const FORMAS = [
    { forma: 'pix', peso: 45 },
    { forma: 'cartao', peso: 40 },
    { forma: 'boleto', peso: 15 },
];

const NOMES = [
    'Ana Carolina Silva', 'Bruno Henrique Santos', 'Camila Oliveira Lima',
    'Diego Fernandes Costa', 'Eduarda Martins Souza', 'Felipe Rodrigues Alves',
    'Gabriela Pereira Dias', 'Henrique Moura Castro', 'Isabella Carvalho Rocha',
    'Joao Victor Mendes', 'Karla Nascimento Pinto', 'Lucas Teixeira Freitas',
    'Mariana Barbosa Nunes', 'Nicolas Azevedo Gomes', 'Olivia Monteiro Lopes',
    'Pedro Henrique Cunha', 'Rafaela Ribeiro Vieira', 'Samuel Fonseca Cardoso',
    'Tatiana Batista Araujo', 'Victor Hugo Andrade',
];

// Taxas de abandono por etapa (comportamento realista de e-commerce educacional)
const TAXAS = {
    checkout_para_pedido: 0.82, // 18% abandona no checkout
    pedido_para_pagamento: 0.91, // 9% abandona apos criar pedido
    pagamento_aprovado: 0.94, // 6% tem pagamento recusado
};

function randomItem(arr) {
    return arr[Math.floor(Math.random() * arr.length)];
}

function weightedForma() {
    const total = FORMAS.reduce((s, f) => s + f.peso, 0);
    let r = Math.random() * total;
    for (const f of FORMAS) { r -= f.peso; if (r <= 0) return f.forma; }
    return 'pix';
}

function calcParcelas(forma, maxParcelas) {
    if (forma === 'pix' || forma === 'boleto') return 1;
    return randomItem([1, 2, 3, 6, 10, 12].filter(p => p <= maxParcelas));
}

function gerarCPF(index) {
    return String(20000000 + index).padStart(9, '0') + '00';
}

function gerarProtocolo(ts) {
    return `PAG-FUNIL-${ts}-${Math.floor(Math.random() * 999)}`;
}

function gerarNumeroPedido(ts) {
    return `PED-F-${ts.toString(36).toUpperCase()}-${Math.floor(Math.random() * 9999).toString(36).toUpperCase()}`;
}

function horaAleatoria(dataBase) {
    const d = new Date(dataBase);
    d.setHours(
        8 + Math.floor(Math.random() * 12),
        Math.floor(Math.random() * 60),
        Math.floor(Math.random() * 60)
    );
    return d;
}

async function sendToLogstash(data) {
    try {
        await axios.post(LOGSTASH_URL, data, {
            headers: { 'Content-Type': 'application/json' },
            timeout: 2000,
        });
    } catch {
        // Logstash nao e critico para o seed
    }
}

async function main() {
    const client = await pool.connect();

    try {
        console.log('Iniciando seed do funil de conversao - ultimos 30 dias\n');

        const hoje = new Date();
        let idx = (Date.now() % 9000000) + 100000;
        let stats = { checkouts: 0, pedidos: 0, pagamentos: 0, receita: 0 };

        for (let diasAtras = 29; diasAtras >= 0; diasAtras--) {
            const dataBase = new Date(hoje);
            dataBase.setDate(hoje.getDate() - diasAtras);
            dataBase.setHours(0, 0, 0, 0);

            const diaDoMes = dataBase.getDate();
            let volumeCheckouts;
            if (diaDoMes <= 5) volumeCheckouts = 8 + Math.floor(Math.random() * 5);
            else if (diaDoMes <= 10) volumeCheckouts = 5 + Math.floor(Math.random() * 4);
            else if (diaDoMes <= 20) volumeCheckouts = 3 + Math.floor(Math.random() * 3);
            else if (diaDoMes <= 25) volumeCheckouts = 6 + Math.floor(Math.random() * 4);
            else volumeCheckouts = 9 + Math.floor(Math.random() * 5);

            console.log(`${dataBase.toISOString().slice(0, 10)} - ${volumeCheckouts} checkouts iniciados`);

            for (let i = 0; i < volumeCheckouts; i++) {
                const hora = horaAleatoria(dataBase);
                const ts = hora.getTime();
                const curso = randomItem(CURSOS);
                const forma = weightedForma();
                const nome = randomItem(NOMES);
                const email = `funil.${idx}.${ts}@poliedro.demo`;
                const cpf = gerarCPF(idx++);
                const telef = `119${String(10000000 + idx).slice(0, 8)}`;
                const base = { '@timestamp': hora.toISOString(), service: 'api-pv', level: 'info' };

                // ETAPA 1: Aluno cadastrado (100%)
                const alunoResult = await client.query(
                    `INSERT INTO alunos (nome_completo, cpf, email, telefone, created_at, updated_at)
           VALUES ($1, $2, $3, $4, $5, $5) RETURNING id`,
                    [nome, cpf, email, telef, hora]
                );
                const alunoId = alunoResult.rows[0].id;

                await sendToLogstash({
                    ...base, message: '[METRICA] Aluno cadastrado',
                    business: { transaction: 'aluno_cadastrado', aluno: { id: alunoId, email, created_at: hora } }
                });

                // ETAPA 2: Checkout iniciado (100%)
                await sendToLogstash({
                    ...base, message: '[METRICA] Checkout iniciado',
                    business: { transaction: 'checkout_iniciado', aluno: { id: alunoId }, valor: curso.preco }
                });
                stats.checkouts++;

                // ETAPA 3: Pedido criado (82%)
                if (Math.random() < TAXAS.checkout_para_pedido) {
                    const numPedido = gerarNumeroPedido(ts);
                    const parcelas = calcParcelas(forma, curso.maxParcelas);

                    const pedResult = await client.query(
                        `INSERT INTO pedidos (aluno_id, numero_pedido, status, total, parcelas, created_at, updated_at)
             VALUES ($1, $2, 'aguardando_pagamento', $3, $4, $5, $5) RETURNING id`,
                        [alunoId, numPedido, curso.preco, parcelas, hora]
                    );
                    const pedidoId = pedResult.rows[0].id;

                    await client.query(
                        `INSERT INTO pedido_itens (pedido_id, curso_id, curso_titulo, quantidade, preco_unitario, created_at, updated_at)
             VALUES ($1, $2, $3, 1, $4, $5, $5)`,
                        [pedidoId, curso.id, curso.titulo, curso.preco, hora]
                    );

                    await sendToLogstash({
                        ...base, message: '[METRICA] Pedido criado',
                        business: {
                            transaction: 'pedido_criado',
                            pedido: { id: pedidoId, numero: numPedido, total: curso.preco, status: 'aguardando_pagamento' },
                            aluno: { id: alunoId },
                        }
                    });

                    await sendToLogstash({
                        ...base, message: '[METRICA] Curso comprado',
                        business: {
                            transaction: 'curso_comprado',
                            curso: { id: curso.id, titulo: curso.titulo, quantidade: 1, preco_unitario: curso.preco },
                            pedido: { id: pedidoId },
                            aluno: { id: alunoId },
                            valor_total: curso.preco,
                        }
                    });
                    stats.pedidos++;

                    // ETAPA 4: Pagamento (91% chega, 94% aprovado)
                    if (Math.random() < TAXAS.pedido_para_pagamento) {
                        const protocolo = gerarProtocolo(ts);
                        const aprovado = Math.random() < TAXAS.pagamento_aprovado;
                        const status = aprovado ? 'aprovado' : 'recusado';

                        const pagResult = await client.query(
                            `INSERT INTO pagamentos (aluno_id, forma_pagamento, valor, parcelas, protocolo, status, created_at, updated_at)
               VALUES ($1, $2, $3, $4, $5, $6, $7, $7) RETURNING id`,
                            [alunoId, forma, curso.preco, parcelas, protocolo, status, hora]
                        );
                        const pagId = pagResult.rows[0].id;

                        if (aprovado) {
                            await client.query(
                                `UPDATE pedidos SET status = 'pago', pagamento_id = $1, updated_at = $3 WHERE id = $2`,
                                [pagId, pedidoId, hora]
                            );

                            await sendToLogstash({
                                ...base, message: '[METRICA] Pagamento aprovado',
                                business: {
                                    transaction: 'pagamento_aprovado',
                                    pagamento: { id: pagId, protocolo, forma, parcelas },
                                    pedido: { id: pedidoId },
                                    aluno: { id: alunoId },
                                    valor: curso.preco,
                                    metrics: { receita: curso.preco, conversao: 1 },
                                }
                            });
                            stats.pagamentos++;
                            stats.receita += curso.preco;
                        }
                    }
                }

                await new Promise(r => setTimeout(r, 50));
            }
        }

        console.log('\nSeed do funil concluido!');
        console.log(`  Checkouts iniciados:   ${stats.checkouts}`);
        console.log(`  Pedidos criados:       ${stats.pedidos}  (${(stats.pedidos / stats.checkouts * 100).toFixed(1)}%)`);
        console.log(`  Pagamentos aprovados:  ${stats.pagamentos}  (${(stats.pagamentos / stats.checkouts * 100).toFixed(1)}%)`);
        console.log(`  Receita total:         R$ ${stats.receita.toLocaleString('pt-BR')}`);
        console.log('\nAguarde ~30 segundos para os dados aparecerem no Kibana.');

    } catch (err) {
        console.error('Erro:', err.message);
        throw err;
    } finally {
        client.release();
        await pool.end();
    }
}

main();