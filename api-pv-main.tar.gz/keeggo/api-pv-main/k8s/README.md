# Kubernetes — api-pv-back (Express)

## Recursos

- `deployment.yaml` — Deployment do backend (porta 3001)
- `service.yaml` — Service ClusterIP (porta 80 → 3001)
- `secret-example.yaml` — Exemplo de Secret para o banco (ajuste e aplique)

## Pré-requisitos

1. **Namespace** — todos os recursos usam o namespace `demo`:
   ```bash
   kubectl create namespace demo
   ```

2. **Secret para pull do ACR** (no namespace `demo`):
   ```bash
   kubectl create secret docker-registry acr-secret \
     --docker-server=<ACR_NAME>.azurecr.io \
     --docker-username=<ACR_USER> \
     --docker-password=<ACR_PASSWORD>
   ```

3. **Secret do banco** — crie `api-pv-secrets` no namespace `demo` com as chaves do PostgreSQL:
   ```bash
   kubectl create secret generic api-pv-secrets -n demo \
     --from-literal=db-host=postgres \
     --from-literal=db-port=5432 \
     --from-literal=db-name=poliedro \
     --from-literal=db-user=app \
     --from-literal=db-password=<senha>
   ```
   Ou edite `secret-example.yaml` e aplique.

4. **Substituir no `deployment.yaml`** o placeholder `<ACR_NAME>` pelo nome do seu ACR.

## Aplicar

```bash
kubectl apply -f k8s/ -n demo
```

## Variáveis opcionais

Descomente no `deployment.yaml` as env de Logstash e APM e ajuste, ou use ConfigMap/Secret.
