/**
 * Configuração do Elastic APM para o Consumer
 */
module.exports = {
    serviceName: process.env.ELASTIC_APM_CONSUMER_SERVICE_NAME || 'api-pv-consumer',
    serverUrl: process.env.ELASTIC_APM_SERVER_URL || 'http://localhost:8200',
    environment: process.env.NODE_ENV || 'production',
    active: true,
    transactionSampleRate: 1.0,

    // Consumer só processa mensagens da fila (todas são importantes)
    // Não precisa de filtros adicionais
};