require('dotenv').config();
const apm = require('elastic-apm-node').start(require('./elastic-apm-consumer.js'));

const { ServiceBusClient } = require('@azure/service-bus');
const { logger } = require('../src/lib/logger');

const QUEUE_NAME = process.env.AZURE_SERVICE_BUS_QUEUE_NAME || 'pedidos';
const CONNECTION_STRING = process.env.AZURE_SERVICE_BUS_CONNECTION_STRING;
const MAX_CONCURRENT = parseInt(process.env.CONSUMER_MAX_CONCURRENT || '5', 10);

if (!CONNECTION_STRING) {
    logger.error('[SERVICE_BUS] Consumer não pode iniciar: AZURE_SERVICE_BUS_CONNECTION_STRING não definida', {
        falha_integracao: true,
        motivo: 'connection_string_ausente',
    });
    process.exit(1);
}

const client = new ServiceBusClient(CONNECTION_STRING);
// ALTERADO: usar receiveAndDelete para teste
const receiver = client.createReceiver(QUEUE_NAME, {
    receiveMode: 'receiveAndDelete',  // ← Mudado de 'peekLock' para 'receiveAndDelete'
});

function iniciarTransacaoComTrace(mensagem, traceparent) {
    return apm.startTransaction(
        `Service Bus receive ${mensagem.body?.tipo || 'evento'}`,
        'messaging',
        { childOf: traceparent || undefined }
    );
}

const messageHandler = async (mensagemRecebida) => {
    const { body, applicationProperties, messageId } = mensagemRecebida;
    const traceparent = applicationProperties?.traceparent || null;
    const transaction = iniciarTransacaoComTrace(mensagemRecebida, traceparent);

    logger.info('✅ Mensagem RECEBIDA da queue!', {
        messageId,
        tipo: body?.tipo,
        traceparent: traceparent || 'não disponível',
        queue: QUEUE_NAME,
        payload: body?.payload,
    });

    try {
        // Como é receiveAndDelete, não precisa chamar completeMessage
        logger.info('✅ Mensagem processada com sucesso', { messageId, tipo: body?.tipo });
        transaction?.setOutcome('success');
    } catch (err) {
        logger.error('❌ Erro ao processar mensagem', {
            messageId,
            tipo: body?.tipo,
            error: err.message,
        });
        transaction?.setOutcome('failure');
        apm.captureError(err);
    } finally {
        transaction?.end();
    }
};

const errorHandler = async (err) => {
    logger.error('[SERVICE_BUS] Erro no receiver — consumo da fila interrompido ou falhando', {
        falha_integracao: true,
        erro: err.message,
        codigo: err.code,
        statusCode: err.statusCode,
        nome: err.name,
        stack: err.stack,
    });
    apm.captureError(err);
};

async function iniciar() {
    logger.info('🚀 Consumer iniciando...', {
        queue: QUEUE_NAME,
        maxConcurrent: MAX_CONCURRENT,
        mode: 'receiveAndDelete',
        servico: 'api-pv-consumer',
    });

    try {
        receiver.subscribe(
            { processMessage: messageHandler, processError: errorHandler },
            { maxConcurrentCalls: MAX_CONCURRENT }
        );

        logger.info('[SERVICE_BUS] Consumer inscrito na fila', { queue: QUEUE_NAME });
    } catch (err) {
        logger.error('[SERVICE_BUS] Falha ao subscrever à fila — consumer não está escutando', {
            falha_integracao: true,
            queue: QUEUE_NAME,
            erro: err.message,
            codigo: err.code,
            stack: err.stack,
        });
        apm.captureError(err);
        process.exit(1);
    }
}

iniciar().catch((err) => {
    logger.error('[SERVICE_BUS] Falha fatal ao iniciar consumer', {
        falha_integracao: true,
        erro: err.message,
        stack: err.stack,
    });
    process.exit(1);
});

async function encerrar() {
    logger.info('🛑 Encerrando consumer...');
    await receiver.close();
    await client.close();
    await apm.flush();
    process.exit(0);
}

process.on('SIGINT', encerrar);
process.on('SIGTERM', encerrar);

