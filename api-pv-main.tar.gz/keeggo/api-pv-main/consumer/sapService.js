const axios = require('axios');
const { logger } = require('../src/lib/logger');
const apm = require('elastic-apm-node'); // ← Mover para o topo

const SAP_URL = process.env.SAP_URL;

/**
 * Mapeia o tipo da mensagem para o endpoint correto no SAP
 */
function resolverEndpoint(tipo) {
    const mapa = {
        pedido_criado: '/api/sap/pedidos',
        pagamento_aprovado: '/api/sap/pagamentos',
    };
    return mapa[tipo] || '/api/sap/eventos';
}

/**
 * Envia a mensagem ao SAP propagando o traceparent
 * para manter a cadeia de trace visível no Kibana
 */
async function enviarParaSap(body, traceparent, tracestate) {
    const span = apm.startSpan('SAP HTTP send', 'external', 'http', 'request');

    const endpoint = resolverEndpoint(body?.tipo);

    const headers = {
        'Content-Type': 'application/json',
        ...(traceparent && { traceparent }),
        ...(tracestate && { tracestate }),
    };

    try {
        const resposta = await axios.post(`${SAP_URL}${endpoint}`, body, { headers });

        logger.info('Mensagem enviada ao SAP com sucesso', {
            tipo: body?.tipo,
            endpoint,
            status: resposta.status,
            traceparent: traceparent || 'não disponível',
        });

        span?.setOutcome('success');
        return { sucesso: true, status: resposta.status };
    } catch (err) {
        logger.error('Erro ao chamar o SAP', {
            tipo: body?.tipo,
            endpoint,
            error: err.message,
        });

        span?.setOutcome('failure');
        apm.captureError(err);
        throw err;
    } finally {
        span?.end();
    }
}

module.exports = { enviarParaSap };