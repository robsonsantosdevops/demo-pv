/**
 * Configuração do Elastic APM para a API Express.
 * Variáveis de ambiente têm precedência.
 * @see https://www.elastic.co/guide/en/apm/agent/nodejs/current/configuring-the-agent.html
 */
module.exports = {
  serviceName: process.env.ELASTIC_APM_SERVICE_NAME || 'api-pv',
  serverUrl: process.env.ELASTIC_APM_SERVER_URL || 'http://localhost:8200',
  secretToken: process.env.ELASTIC_APM_SECRET_TOKEN,
  apiKey: process.env.ELASTIC_APM_API_KEY,
  environment: process.env.NODE_ENV || 'development',
  active: process.env.ELASTIC_APM_ACTIVE !== 'false',
  captureBody: 'off',
  transactionSampleRate: 1.0,
  centralConfig: false,
  
  // 🔥 NOVAS CONFIGURAÇÕES PARA FILTRAR
  
  // URLs a serem ignoradas (não geram transações)
  ignoreUrls: [
    '/health',
    '/metrics',
    '/favicon.ico',
    '/api/config'
  ],
  
  // Filtro personalizado para transações
  filter: (payload) => {
    // Só processar transações HTTP
    if (payload.transaction && payload.transaction.type === 'request') {
      const url = payload.transaction?.context?.request?.url?.pathname || '';
      
      // Ignorar rotas de sistema
      const ignoredRoutes = ['/health', '/metrics', '/favicon', '_next', '/api/config'];
      if (ignoredRoutes.some(route => url.includes(route))) {
        return false;
      }
      
      // Só capturar rotas de negócio
      const businessRoutes = ['/api/alunos', '/api/pedidos', '/api/pagamentos'];
      const shouldCapture = businessRoutes.some(route => url.includes(route));
      
      if (!shouldCapture) {
        return false; // Ignorar outras rotas
      }
    }
    
    return true; // Manter a transação
  }
};