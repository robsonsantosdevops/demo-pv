const { ServiceBusClient } = require('@azure/service-bus');

const connectionString = 'Endpoint=sb://demo-poli.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=4LM2c7So9HQD/gJ2iB6/diWftnPXBS7jx+ASbGbPx4I=';
const queueName = 'pedidos';

async function sendMessage() {
    const client = new ServiceBusClient(connectionString);
    const sender = client.createSender(queueName);
    
    const message = {
        body: {
            tipo: 'teste_manual',
            payload: { test: true, timestamp: new Date().toISOString() },
            correlation_id: 'teste-manual-123'
        },
        applicationProperties: {
            tipo: 'teste_manual',
            source: 'cli'
        }
    };
    
    await sender.sendMessages(message);
    console.log('✅ Mensagem enviada para queue:', queueName);
    await sender.close();
    await client.close();
}

sendMessage().catch(console.error);
