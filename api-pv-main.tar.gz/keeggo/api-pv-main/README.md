# API PV — Backend Poliedro

API Express (Node.js) para alunos, pagamentos e pedidos.

## Como rodar

```bash
npm install
npm run dev   # desenvolvimento (nodemon)
# ou
npm start     # produção
```

Variáveis de ambiente (ex.: `.env`): `PORT`, `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD`.

## Logs (Logstash) e APM (Elastic)

A aplicação envia **logs para o Logstash** e está instrumentada com **Elastic APM** para **tracing** e **dependências**.

### Logstash (logs)

- Os logs do servidor (Winston) são enviados ao Logstash via **TCP** quando as variáveis abaixo estiverem definidas.
- Uso do logger: `const { logger } = require('./src/lib/logger');` e então `logger.info('mensagem', { chave: 'valor' });`.

**Variáveis de ambiente:**

| Variável        | Descrição                    | Exemplo    |
|-----------------|------------------------------|------------|
| `LOGSTASH_HOST` | Host do Logstash (input TCP) | `logstash` |
| `LOGSTASH_PORT` | Porta do input TCP           | `28777`    |
| `LOG_LEVEL`     | Nível do logger              | `info`, `debug` |

**Exemplo de pipeline Logstash (input TCP):**

```ruby
input {
  tcp { port => 28777 type => "nodejs" codec => json }
}
filter {
  json { source => "message" }
}
output {
  elasticsearch { hosts => ["elasticsearch:9200"] }
}
```

### Elastic APM (tracing e dependências)

- O agente **Elastic APM** é iniciado no início de `server.js` (após `dotenv`), gerando **tracing**, **métricas** e **dependências** no APM Server.
- Configuração em `elastic-apm-node.js` na raiz; variáveis de ambiente têm precedência.

**Variáveis de ambiente:**

| Variável                   | Descrição              | Exemplo                 |
|----------------------------|------------------------|-------------------------|
| `ELASTIC_APM_SERVICE_NAME` | Nome do serviço no APM  | `api-pv`                |
| `ELASTIC_APM_SERVER_URL`   | URL do APM Server      | `http://localhost:8200` |
| `ELASTIC_APM_SECRET_TOKEN` | Token (se exigido)     | —                       |
| `ELASTIC_APM_API_KEY`      | API key (alternativa)  | —                       |
| `ELASTIC_APM_ACTIVE`       | Desativar: `false`     | `true` (padrão)         |

**Endpoints:** `POST/GET /api/alunos`, `POST/GET /api/pagamentos`, `POST/GET /api/pedidos`, `GET /health`, `GET /metrics`.
