const { ServiceBusClient } = require('@azure/service-bus');

const connectionString = 'Endpoint=sb://demo-poli.servicebus.windows.net/;SharedAccessKeyName=RootManageSharedAccessKey;SharedAccessKey=4LM2c7So9HQD/gJ2iB6/diWftnPXBS7jx+ASbGbPx4I=';

console.log('🔍 Testando conexão com Service Bus...');

async function testConnection() {
    try {
        const client = new ServiceBusClient(connectionString);
        const receiver = client.createReceiver('pedidos');
        console.log('✅ Conexão com Service Bus funcionou! Queue "pedidos" acessível.');
        await receiver.close();
        await client.close();
        process.exit(0);
    } catch (e) {
        console.error('❌ Erro:', e.message);
        process.exit(1);
    }
}

testConnection();
