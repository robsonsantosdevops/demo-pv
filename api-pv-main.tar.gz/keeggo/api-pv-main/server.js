// server.js — dotenv primeiro para variáveis de ambiente; APM em seguida
require('dotenv').config();
require('elastic-apm-node').start(require('./elastic-apm-node.js'));

const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const db = require('./src/models/database');
const { logger } = require('./src/lib/logger');
const { closeSender } = require('./src/messaging/producer.js');

const app = express();
const port = process.env.PORT || 3001;

// Middleware
app.use(helmet());
app.use(cors({
    allowedHeaders: ['Content-Type', 'Authorization', 'traceparent', 'tracestate'],
    exposedHeaders: ['traceparent', 'tracestate'],
}));
app.use(express.json());

// Middleware para log de requisições (logs vão para Logstash se configurado)
app.use((req, res, next) => {
    logger.info(`${req.method} ${req.url}`, { method: req.method, url: req.url });
    next();
});

// Rotas
app.use('/api', require('./src/routes/alunoRoutes'));
app.use('/api', require('./src/routes/pagamentoRoutes'));
app.use('/api', require('./src/routes/pedidoRoutes')); // ← NOVA ROTA DE PEDIDOS
app.use('/api/mensageria', require('./src/routes/mensageriaRoutes'));

// Rota de health check
app.get('/health', async (req, res) => {
    logger.info('Health check requested');
    const dbStatus = await db.testConnection().catch(() => false);
    res.json({
        status: 'OK',
        timestamp: new Date(),
        banco: dbStatus ? 'conectado' : 'desconectado',
        servico: 'api-pv',
        versao: '1.0.0',
    });
});

// Rota de métricas (para o Zabbix/Prometheus depois)
app.get('/metrics', (req, res) => {
    res.json({
        uptime: process.uptime(),
        memoria: process.memoryUsage(),
        conexoes_ativas: db.pool?.totalCount || 0,
        conexoes_ociosas: db.pool?.idleCount || 0
    });
});

// Tratamento de erro 404 (rota não encontrada)
app.use((req, res) => {
    res.status(404).json({ erro: 'Rota não encontrada' });
});


// Tratamento de erros global
app.use((err, req, res, next) => {
    logger.error('Erro global', { error: err.message, stack: err.stack });
    res.status(500).json({
        erro: 'Erro interno do servidor',
        mensagem: process.env.NODE_ENV === 'development' ? err.message : undefined,
    });
});

// Iniciar servidor
app.listen(port, async () => {
    logger.info(`Servidor rodando em http://localhost:${port}`, { port });
    logger.info('Rotas disponíveis: POST/GET /api/alunos, /api/pagamentos, /api/pedidos, GET /health, /metrics');
    const conectado = await db.testConnection();
    if (!conectado) {
        logger.warn('Servidor iniciado sem conexão com banco de dados');
    }

    if (!process.env.AZURE_SERVICE_BUS_CONNECTION_STRING) {
        logger.warn('[SERVICE_BUS] AZURE_SERVICE_BUS_CONNECTION_STRING não definida — envios para a fila falharão até configurar o ambiente');
    } else {
        logger.info('[SERVICE_BUS] Variável de conexão definida; fila alvo', {
            queue: process.env.AZURE_SERVICE_BUS_QUEUE_NAME || 'pedidos',
        });
    }
});

// Graceful shutdown
process.on('SIGINT', async () => {
    logger.info('Encerrando servidor...');
    await closeSender();
    await db.close();
    process.exit(0);
});
